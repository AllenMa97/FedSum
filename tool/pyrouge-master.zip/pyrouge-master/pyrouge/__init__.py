from pyrouge.base import Doc, Sent
from pyrouge.rouge import Rouge155